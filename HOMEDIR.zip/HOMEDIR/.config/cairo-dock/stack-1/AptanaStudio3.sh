[Desktop Entry]
Name=AptanaStudio3.sh
Date=1465383362
Order=1465074161
Content=file:///.Applications/Aptana_Studio_3/AptanaStudio3.sh
