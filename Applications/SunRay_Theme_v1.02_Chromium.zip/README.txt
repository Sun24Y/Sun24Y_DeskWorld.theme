
SunRay Chromium-Theme by Awebgo
________________________________________________________________________________

Just drag & drop the .CRX file into the browser viewport to activate the new theme.

eMail: awebgo.net@gmail.com