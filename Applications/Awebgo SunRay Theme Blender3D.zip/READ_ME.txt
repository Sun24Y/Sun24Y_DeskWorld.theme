##
#
# AWEBGO "SunRay" Blender3D-Theme v1.0
#

Just install the .XML-file with the Blender User-Preferences panel and activate the Theme in the options.

Enjoy...

--
Done by: Arjuna Noorsanto in 10/2015

http://loop.arcturus.uberspace.de/